import { CONFIG } from "./config.js";
import { impliedVol, greeks, gexValue } from "./math.js";

function num(v) {
  if (v === null || v === undefined) return null;
  const s = String(v).replace(/[$,%\s,]/g, "");
  if (!s || s === "--") return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function parseLastTrade(text) {
  const m = String(text || "").match(/\$([\d,.]+)/);
  return m ? num(m[1]) : null;
}

function expiryYear(month, day, now = new Date()) {
  const months = {Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11};
  const mm = months[month];
  if (mm === undefined) return now.getFullYear();
  let y = now.getFullYear();
  const d = new Date(y, mm, day, 16, 0, 0);
  if (d.getTime() < now.getTime() - 86400000*30) y++;
  return y;
}

function normalizeDate(label) {
  if (!label) return null;
  const m = String(label).match(/([A-Z][a-z]{2})\s+(\d{1,2})(?:,\s*(\d{4}))?/);
  if (!m) return null;
  const monthMap = {Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11};
  const year = m[3] ? Number(m[3]) : expiryYear(m[1], Number(m[2]));
  return new Date(year, monthMap[m[1]], Number(m[2]), 16, 0, 0);
}

export async function fetchChain(symbol) {
  const url = `${CONFIG.workerBase}/options?symbol=${encodeURIComponent(symbol)}`;
  const response = await fetch(url, {cache:"no-store"});
  if (!response.ok) throw new Error(`Worker HTTP ${response.status}`);
  const payload = await response.json();
  const table = payload?.data?.table;
  const rawRows = table?.rows;
  if (!Array.isArray(rawRows)) throw new Error("La respuesta no contiene la cadena.");
  const spot = parseLastTrade(payload?.data?.lastTrade);

  let currentExpiry = null;
  const rows = [];
  for (const row of rawRows) {
    if (row.expirygroup) {
      currentExpiry = normalizeDate(row.expirygroup);
      continue;
    }
    const strike = num(row.strike);
    if (!strike) continue;
    const explicit = normalizeDate(row.expiryDate);
    const expiry = explicit || currentExpiry;
    if (!expiry) continue;

    rows.push({
      expiry,
      expiryKey: expiry.toISOString().slice(0,10),
      strike,
      callBid: num(row.c_Bid),
      callAsk: num(row.c_Ask),
      callLast: num(row.c_Last),
      callVolume: num(row.c_Volume) || 0,
      callOi: num(row.c_Openinterest) || 0,
      putBid: num(row.p_Bid),
      putAsk: num(row.p_Ask),
      putLast: num(row.p_Last),
      putVolume: num(row.p_Volume) || 0,
      putOi: num(row.p_Openinterest) || 0
    });
  }
  return {symbol, spot, rows, fetchedAt:new Date(), source:"Nasdaq vía Cloudflare"};
}

function midpoint(bid, ask, last) {
  if (bid !== null && ask !== null && ask >= bid && ask > 0) return (bid+ask)/2;
  return last && last > 0 ? last : null;
}

export function enrichRows(rows, spot) {
  const now = Date.now();
  return rows.map(row => {
    const T = Math.max((row.expiry.getTime()-now)/(365*24*3600*1000), 0.5/365);
    const callMid = midpoint(row.callBid,row.callAsk,row.callLast);
    const putMid = midpoint(row.putBid,row.putAsk,row.putLast);
    const callIv = impliedVol("call",callMid,spot,row.strike,T,CONFIG.riskFreeRate);
    const putIv = impliedVol("put",putMid,spot,row.strike,T,CONFIG.riskFreeRate);
    const cg = callIv ? greeks("call",spot,row.strike,T,CONFIG.riskFreeRate,callIv) : {};
    const pg = putIv ? greeks("put",spot,row.strike,T,CONFIG.riskFreeRate,putIv) : {};
    const callGex = gexValue("call",row.callOi,cg.gamma,spot);
    const putGex = gexValue("put",row.putOi,pg.gamma,spot);
    return {...row, T, callMid, putMid, callIv, putIv, callDelta:cg.delta,
      putDelta:pg.delta, callGamma:cg.gamma, putGamma:pg.gamma,
      callTheta:cg.theta, putTheta:pg.theta, callGex, putGex,
      netGex:callGex+putGex};
  });
}
