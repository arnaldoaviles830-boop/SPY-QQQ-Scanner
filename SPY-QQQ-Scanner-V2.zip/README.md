# SPY / QQQ Scanner V2

Aplicación estática para GitHub Pages conectada al Cloudflare Worker:

`https://young-term-3722.arnaldo-aviles830.workers.dev`

## Instalación

1. Sube todos estos archivos a la raíz del repositorio `SPY-QQQ-Scanner`.
2. Sustituye el `index.html` anterior.
3. En GitHub Pages usa la rama principal y carpeta raíz.
4. Espera 1–3 minutos y abre la página.

## Funciones

- SPY y QQQ.
- Actualización automática cada 2 minutos.
- Selección de vencimiento.
- Delta, gamma, theta e IV estimadas mediante Black‑Scholes.
- GEX neto estimado.
- Call Wall, Put Wall, Max Pain y Zero Gamma aproximado.
- Expected Move.
- Strikes orientativos para spreads de $1.

## Limitaciones

Nasdaq no entrega griegas en esta respuesta. La app infiere IV desde el precio medio bid/ask y luego calcula griegas. Los datos gratuitos pueden estar retrasados y la metodología GEX es una aproximación educativa.
