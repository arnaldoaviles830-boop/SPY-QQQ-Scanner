import { CONFIG } from "./config.js";
import { fetchChain, enrichRows } from "./options.js";
import { maxPain } from "./math.js";

const state = {symbol:CONFIG.defaultSymbol, raw:null, rows:[], timer:null};
const $ = id => document.getElementById(id);
const money = n => Number.isFinite(n) ? `$${n.toFixed(2)}` : "—";
const pct = n => Number.isFinite(n) ? `${(n*100).toFixed(1)}%` : "—";
const compact = n => {
  if (!Number.isFinite(n)) return "—";
  const a=Math.abs(n), s=n<0?"-":"";
  if(a>=1e9)return s+(a/1e9).toFixed(2)+"B";
  if(a>=1e6)return s+(a/1e6).toFixed(2)+"M";
  if(a>=1e3)return s+(a/1e3).toFixed(1)+"K";
  return Math.round(n).toString();
};

function setStatus(text, kind=""){ const e=$("status"); e.textContent=text; e.className=`status ${kind}`; }

function expiries(rows){
  return [...new Map(rows.map(r=>[r.expiryKey,r.expiry])).entries()].sort((a,b)=>a[1]-b[1]);
}

function selectedRows(){
  const key=$("expiry").value;
  return state.rows.filter(r=>r.expiryKey===key);
}

function nearestByDelta(rows, side, target){
  const candidates = rows.filter(r => side==="put" ? Number.isFinite(r.putDelta) : Number.isFinite(r.callDelta));
  return candidates.sort((a,b)=>{
    const da=Math.abs(Math.abs(side==="put"?a.putDelta:a.callDelta)-target);
    const db=Math.abs(Math.abs(side==="put"?b.putDelta:b.callDelta)-target);
    return da-db;
  })[0] || null;
}

function zeroGamma(rows){
  const sorted=[...rows].sort((a,b)=>a.strike-b.strike);
  let cum=0, prev=null;
  for(const r of sorted){
    const next=cum+r.netGex;
    if(prev && Math.sign(cum)!==Math.sign(next)){
      const ratio=Math.abs(cum)/(Math.abs(cum)+Math.abs(next));
      return prev.strike+(r.strike-prev.strike)*ratio;
    }
    cum=next; prev=r;
  }
  return sorted.reduce((best,r)=>Math.abs(r.netGex)<Math.abs(best.netGex)?r:best,sorted[0])?.strike ?? null;
}

function render(){
  const rows=selectedRows();
  const spot=state.raw?.spot;
  if(!rows.length || !spot) return;

  const net=rows.reduce((s,r)=>s+r.netGex,0);
  const callWall=[...rows].sort((a,b)=>b.callOi-a.callOi)[0];
  const putWall=[...rows].sort((a,b)=>b.putOi-a.putOi)[0];
  const mp=maxPain(rows);
  const zg=zeroGamma(rows);
  const atm=[...rows].sort((a,b)=>Math.abs(a.strike-spot)-Math.abs(b.strike-spot))[0];
  const atmIv=[atm?.callIv,atm?.putIv].filter(Number.isFinite);
  const iv=atmIv.length?atmIv.reduce((a,b)=>a+b,0)/atmIv.length:null;
  const days=Math.max((rows[0].expiry-Date.now())/86400000,0.5);
  const em=iv?spot*iv*Math.sqrt(days/365):null;

  $("spot").textContent=money(spot);
  $("source").textContent=`${state.raw.source} · ${state.raw.fetchedAt.toLocaleTimeString()}`;
  $("netGex").textContent=compact(net); $("netGex").className=`metric ${net>=0?"positive":"negative"}`;
  $("callWall").textContent=money(callWall?.strike); $("callWallOi").textContent=`OI ${compact(callWall?.callOi)}`;
  $("putWall").textContent=money(putWall?.strike); $("putWallOi").textContent=`OI ${compact(putWall?.putOi)}`;
  $("maxPain").textContent=money(mp); $("zeroGamma").textContent=money(zg);
  $("atmIv").textContent=pct(iv); $("expectedMove").textContent=em?`±${money(em)}`:"—";

  const target=Number($("delta").value);
  const put=nearestByDelta(rows,"put",target), call=nearestByDelta(rows,"call",target);
  const width=CONFIG.spreadWidth;
  if(net>0){
    $("strategy").textContent="Iron Condor conservador / Put Credit Spread";
    $("strategyDetail").textContent=put&&call
      ? `PCS ${money(put.strike)}/${money(put.strike-width)} · CCS ${money(call.strike)}/${money(call.strike+width)} · objetivo |Δ|≈${target}`
      : "No hay contratos suficientes para construir strikes.";
  }else{
    $("strategy").textContent="Sesgo direccional; reducir tamaño";
    $("strategyDetail").textContent=spot<zg && put
      ? `Gamma negativa y precio bajo Zero Gamma. Referencia PCS: ${money(put.strike)}/${money(put.strike-width)}, solo con confirmación alcista.`
      : call ? `Gamma negativa. Referencia CCS: ${money(call.strike)}/${money(call.strike+width)}, solo con confirmación bajista.` : "Esperar mejor estructura.";
  }
  $("regime").textContent=net>=0?"Gamma positiva: posible compresión":"Gamma negativa: posible expansión";
  $("regimeDetail").textContent=net>=0
    ?"Los movimientos pueden tender a revertir hacia strikes con mayor OI."
    :"Puede aumentar la velocidad del movimiento; walls y Zero Gamma ganan importancia.";

  const visible=[...rows].sort((a,b)=>Math.abs(a.strike-spot)-Math.abs(b.strike-spot))
    .slice(0,CONFIG.maxRows).sort((a,b)=>a.strike-b.strike);
  $("chainBody").innerHTML=visible.map(r=>`<tr class="${Math.abs(r.strike-spot)<1?"atm":""}">
    <td>${r.strike.toFixed(2)}</td><td>${Number.isFinite(r.callDelta)?r.callDelta.toFixed(3):"—"}</td>
    <td>${pct(r.callIv)}</td><td>${compact(r.callOi)}</td><td class="positive">${compact(r.callGex)}</td>
    <td class="negative">${compact(r.putGex)}</td><td>${compact(r.putOi)}</td><td>${pct(r.putIv)}</td>
    <td>${Number.isFinite(r.putDelta)?r.putDelta.toFixed(3):"—"}</td></tr>`).join("");
}

async function load(preserveExpiry=false){
  try{
    setStatus(`Consultando ${state.symbol}…`);
    $("refresh").disabled=true;
    const old=$("expiry").value;
    const raw=await fetchChain(state.symbol);
    if(!raw.spot) throw new Error("Nasdaq no devolvió el precio.");
    state.raw=raw; state.rows=enrichRows(raw.rows,raw.spot);
    const exps=expiries(state.rows);
    $("expiry").innerHTML=exps.map(([key,date])=>`<option value="${key}">${date.toLocaleDateString("es-US",{weekday:"short",month:"short",day:"numeric"})}</option>`).join("");
    if(preserveExpiry && exps.some(([k])=>k===old)) $("expiry").value=old;
    render(); setStatus(`${state.symbol} actualizado correctamente. Próxima actualización automática en 2 minutos.`,"ok");
  }catch(err){setStatus(`Error: ${err.message}`,"err");}
  finally{$("refresh").disabled=false;}
}

document.querySelectorAll(".symbol").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".symbol").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active"); state.symbol=btn.dataset.symbol; load(false);
}));
$("expiry").addEventListener("change",render);
$("delta").addEventListener("change",render);
$("refresh").addEventListener("click",()=>load(true));

load(false);
state.timer=setInterval(()=>load(true),CONFIG.refreshMs);
