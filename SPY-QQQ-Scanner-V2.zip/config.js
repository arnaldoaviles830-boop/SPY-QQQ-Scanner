export const CONFIG = {
  workerBase: "https://young-term-3722.arnaldo-aviles830.workers.dev",
  refreshMs: 120000,
  riskFreeRate: 0.043,
  defaultSymbol: "SPY",
  defaultDelta: 0.15,
  spreadWidth: 1,
  maxRows: 28
};
