const SQRT_2PI = Math.sqrt(2 * Math.PI);

export function normPdf(x) {
  return Math.exp(-0.5 * x * x) / SQRT_2PI;
}

export function normCdf(x) {
  const sign = x < 0 ? -1 : 1;
  const z = Math.abs(x) / Math.sqrt(2);
  const t = 1 / (1 + 0.3275911 * z);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
  const a4 = -1.453152027, a5 = 1.061405429;
  const erf = 1 - (((((a5*t+a4)*t)+a3)*t+a2)*t+a1)*t*Math.exp(-z*z);
  return 0.5 * (1 + sign * erf);
}

export function bsPrice(type, S, K, T, r, sigma) {
  if (!(S > 0 && K > 0 && T > 0 && sigma > 0)) return 0;
  const d1 = (Math.log(S/K) + (r + 0.5*sigma*sigma)*T) / (sigma*Math.sqrt(T));
  const d2 = d1 - sigma*Math.sqrt(T);
  if (type === "call") return S*normCdf(d1) - K*Math.exp(-r*T)*normCdf(d2);
  return K*Math.exp(-r*T)*normCdf(-d2) - S*normCdf(-d1);
}

export function impliedVol(type, marketPrice, S, K, T, r) {
  if (!(marketPrice > 0 && S > 0 && K > 0 && T > 0)) return null;
  const intrinsic = type === "call" ? Math.max(0, S-K) : Math.max(0, K-S);
  if (marketPrice < intrinsic) return null;
  let lo = 0.01, hi = 5;
  for (let i=0; i<70; i++) {
    const mid = (lo+hi)/2;
    const p = bsPrice(type, S, K, T, r, mid);
    if (p > marketPrice) hi = mid; else lo = mid;
  }
  const iv = (lo+hi)/2;
  return Number.isFinite(iv) ? iv : null;
}

export function greeks(type, S, K, T, r, sigma) {
  if (!(S > 0 && K > 0 && T > 0 && sigma > 0)) {
    return {delta:null, gamma:null, theta:null};
  }
  const rt = Math.sqrt(T);
  const d1 = (Math.log(S/K) + (r + 0.5*sigma*sigma)*T)/(sigma*rt);
  const d2 = d1 - sigma*rt;
  const gamma = normPdf(d1)/(S*sigma*rt);
  const delta = type === "call" ? normCdf(d1) : normCdf(d1)-1;
  const first = -(S*normPdf(d1)*sigma)/(2*rt);
  const theta = type === "call"
    ? (first - r*K*Math.exp(-r*T)*normCdf(d2))/365
    : (first + r*K*Math.exp(-r*T)*normCdf(-d2))/365;
  return {delta, gamma, theta};
}

export function gexValue(type, oi, gamma, spot) {
  if (!(oi >= 0 && gamma >= 0 && spot > 0)) return 0;
  const raw = oi * gamma * 100 * spot * spot * 0.01;
  return type === "call" ? raw : -raw;
}

export function maxPain(rows) {
  if (!rows.length) return null;
  const strikes = [...new Set(rows.map(r => r.strike))].sort((a,b)=>a-b);
  let best = null;
  for (const settle of strikes) {
    let pain = 0;
    for (const r of rows) {
      pain += Math.max(0, settle-r.strike) * r.callOi * 100;
      pain += Math.max(0, r.strike-settle) * r.putOi * 100;
    }
    if (!best || pain < best.pain) best = {strike:settle, pain};
  }
  return best?.strike ?? null;
}
